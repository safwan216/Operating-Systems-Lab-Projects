#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main(int argc,char *argv[])
{
    int src;
    int dest;
    //Check number of arguments
    if(argc != 3)
    {
        printf("\n Usage: Not enough arguments\n");
        return 1;
    }

    //Set global error variable
    errno = 0;

    //Open source file in read only mode
    src = open(argv[1],O_RDONLY);

    //Open destination file in read/write mode and truncate or create if does not exist
    dest = open(argv[2],O_RDWR|O_CREAT|O_TRUNC,0666);

    // Check if error with opening source file
    if(src == -1)
    {
        printf("Source file failed with error\n");
        perror("open");
        return -1;
    }
    else
    {
        //Check if error with opening destination file
        if(dest == -1)
        {
            printf("Destination file failed with error\n");
            perror("open");
            return -1;
        }
        else
        {
            char c[1]; //Create buffer
            char abc[3] = {'A','B','C'}; //Create array with ABC
            int count = 0; //Initialize count
            while(read(src,&c,1)) //Read from source one character at a time
            {
                count++;//Increment Count
                
                //Replace 5 with O
                if(c[0] == '5')
                {
                    c[0] = 'O';
                    write(dest,c,1);
                }
                else
                    write(dest,c,1);

                //Reset Count and write XYZ
                if(count == 75)
                {
                    count = 0;
                    write(dest,abc,3);
                }
                
            }
            //Close files
            close(src);
            close(dest);
        }
    }
    return 0;
}