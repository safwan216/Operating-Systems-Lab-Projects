#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
 
#define BUFF_SIZE 1024
 
int main(int argc, char* argv[])
{
    int src;
    int dest;
    int nread;
    int nwrite;
    char *buff[BUFF_SIZE];
    
    /*Check if both src & dest files are received or --help is received to get usage*/
    if(argc != 3 || argv[1] == "--help")
    {
        printf("\nUsage: cpcmd source_file destination_file\n");
        return 0;
    }
 
    /*Open source file*/
    src = open(argv[1],O_RDONLY);
 
    if(src == -1)
    {
        printf("\nError opening file %s errno = %d\n",argv[1],errno);
        return 0;
    }
    
    /*Open destination file with respective flags & modes
      O_CREAT & O_TRUNC is to truncate existing file or create a new file
      S_IXXXX are file permissions for the user,groups & others*/
    dest = open(argv[2],O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
 
    if(dest == -1)
    {
        printf("\nError opening file %s errno = %d\n",argv[2],errno);
        return 0;
    }
 
    /*Start data transfer from src file to dest file till it reaches EOF*/
    while((nread = read(src,buff,BUFF_SIZE)) > 0)
    {
        if(write(dest,buff,nread) != nread){
            printf("\nError in writing data to %s\n",argv[2]);
        	perror("open");
        }
    }
    
    if(nread == -1){
        printf("\nError in reading data from %s\n",argv[1]);
    	perror("open");
    }
    
    if(close(src) == -1){
        printf("\nError in closing file %s\n",argv[1]);
    	perror("open");
    }
 
    if(close(dest) == -1){
        printf("\nError in closing file %s\n",argv[2]);
    	perror("open");
    }
 
    return 0;
}