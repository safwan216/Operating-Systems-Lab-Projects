#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
	//parent P
	int a=10, b=25, fq=0, fr=0;
	fq=fork(); // fork a child - call it Process Q
	if(fq==0){ // Child successfully forked
		a= a+b;
		printf("a: %i, b: %i, pid: %i\n",a,b,getpid());
		fr=fork(); // fork another child - call it Process R

		if(fr!=0){
		b= b+20;
		printf("a: %i, b: %i, pid: %i\n",a,b,getpid());
		}

		else{
		a= (a*b)+30;
		printf("a: %i, b: %i, pid: %i\n",a,b,getpid());
		}
	}
	else{
	b= a+b-5;
	printf("a: %i, b: %i, pid: %i\n",a,b,getpid());
	}
}