#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
	int childOne = fork();
	int statusOfFirst;

	if(childOne == -1){
		perror("Fork failed");
		return -1;
	}
	else{
		if(childOne == 0){
			printf("I am child one, my pid is: %i\n", getpid());
			return 0;
		}
		else{
			int childTwo = fork();
			int statusOfSecond;

			if(childTwo == -1){
			perror("Fork failed");
			return -1;
			}
			else{
				if(childTwo == 0){
				printf("I am child two, my pid is: %i\n", getpid());
				return 0;
				}
				else{
					waitpid(childOne, &statusOfFirst, 0);
					waitpid(childTwo, &statusOfSecond, 0);
					printf("Parent process has been terminated\n");
					return 0;
				}
			}
		}
	}
}