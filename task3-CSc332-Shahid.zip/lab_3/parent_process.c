#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main (int argc, char *argv[]) 
{
	int child1 = fork();
	int status1;
	if(child1 ==-1)
	{
		perror("Fork Failed");
		return -1;
	}
	else
	{
		if(child1 == 0)
		{
			printf("I am child one. Here is my pid is: %i\n",getpid());
			char *args[]={"process_P1",NULL}; 
			execv(args[0],args);
			printf ("EXECV Failed\n");
			return 0;
		}
		else
		{
			waitpid(child1,&status1,0);
			int child2 = fork();
			int status2;
			if(child2 == 0)
			{
				printf("I am child two. Here is my pid is: %i\n",getpid());
				char *args[]={"process_P2",NULL}; 
				execv(args[0],args);
				printf ("EXECV Failed\n");
				return 0;
			}
			else
			{
				waitpid(child2,&status2,0);
				printf("Parent has been terminated\n");
				return 0;
			}
		}
	}
}