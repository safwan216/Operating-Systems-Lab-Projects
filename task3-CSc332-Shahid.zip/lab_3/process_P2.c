#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main(int argc,char *argv[])
{
	int sourceid;
	int destinationid;
	int destinationid2;

	//Open source file in read only mode
	sourceid = open("source.txt",O_RDONLY);

	//Open destination files in read/write mode and create if does not exist
	destinationid = open("destination1.txt",O_RDWR);
	destinationid2 = open("destination2.txt",O_RDWR);

	// Check if error with opening source file
	if(sourceid == -1)
	{
		printf("Source file failed with error\n");
		perror("open");
		return -1;
	}
	else
	{
		//Check if error with opening destination file
		if(destinationid == -1 || destinationid2 == -1)
		{
			printf("Destination file failed with error\n");
			perror("open");
			return -1;
		}
		else
		{
			char c[1]; //Create buffer
			int count = 0; //Initialize count
			int turn = 1; //Check which file to write to
			while(read(sourceid,&c,1)) //Read from source one character at a time
			{
				count++;//Increment Count
				
				if(turn == 1) //If first file
				{
					if(count < 101)//While less then 100 chars
						write(destinationid,c,1);
					else
					{
						turn  = 2; //Change file
						count = 0; //Reset Count
					}
				}
				else
				{//Second file
					if(count < 51)//While less then 100 chars
						write(destinationid2,c,1);
					else
					{
						turn  = 1; //Change file
						count = 0; //Reset Count
					}
				}
				
				
			}
			//Close files
			close(sourceid);
			close(destinationid);
			close(destinationid2);
		}
	}
	return 0;
}