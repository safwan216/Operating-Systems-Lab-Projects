#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
int main (int argc, char *argv[]) 
{
	int child = fork();
	int status;
	if(child ==-1)
	{
		perror("Fork Failed");
		return -1;
	}
	else
	{
		if(child == 0)
		{
			printf("I am child one. Here is my pid is: %i\n",getpid());
			execl("/bin/date","/bin/date",NULL);
			printf ("EXECL Failed\n");
			return 0;
		}
		else
		{
			waitpid(child,&status,0);
			printf("Parent has been terminated\n");
			return 0;
		}
	}
}