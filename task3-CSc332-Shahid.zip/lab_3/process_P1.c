#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main(int argc,char *argv[])
{
	int fd;
	int fd1;
	errno = 0;
	//Create 1st file
	fd = open("destination1.txt",O_RDONLY|O_CREAT|O_TRUNC,0777);
	if(fd == -1)
	{
		//printf("\n open() failed with error [%s]\n",strerror(errno));
		perror("open");
		return -1;
	}
	else
	{
		close(fd);
		//Create 2nd file
		fd1 = open("destination2.txt",O_RDONLY|O_CREAT|O_TRUNC,0777);
		if(fd1 == -1)
		{
			//printf("\n open() failed with error [%s]\n",strerror(errno));
			perror("open");
			return -1;
		}
		else
		{
			close(fd1);
			return 0;
		}
	}
	return 0;
}