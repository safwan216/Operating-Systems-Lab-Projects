#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    printf("Welcome to the shell, please type a command or type quit to exit:\n");
    int BUFF_SIZE = 1024; // Size of the input string
    int MAX_ARGS = 64;    // Maximum number of arguments allowed
    int arg_count = 0;    // Initialize argument count

    char delim[] = " \n\t";  // Sets delimeters for string splitting
    char* curr_arg;          // Declares current token from split
    char* args[MAX_ARGS];    // Declares array to store all args

    char* input_string = malloc(BUFF_SIZE * sizeof(char));      // Allocates memory for input string
    char* input_string_copy = malloc(BUFF_SIZE * sizeof(char)); // Allocates memory for copy of input string
    char* quit_string = "quit\n";                               // Keyword for quitting shell
    input_string[0] = 'a';                                      // Temporary value in input string

    while(strcmp(input_string,quit_string) != 0)  // Checks if quit keyword
    {
        printf(">>");
        fgets(input_string,BUFF_SIZE,stdin);      // Gets user input and puts it into the input_string
        strcpy(input_string_copy,input_string);   // Copies input string

        curr_arg = strtok(input_string_copy, delim); // First token from split

        while(curr_arg != NULL)                 // While there are tokens left to split
        {
            args[arg_count] = curr_arg;         // Add token to array
            arg_count++;                        // Increment number of argumentss
            curr_arg = strtok(NULL, delim);     // Sets 'curr_arg' to next token
        }

        args[arg_count] = NULL; // Sets the last token to NULL for exec

        int child = fork(); // Creates child
        int status;         // A temporary variable to store the termination status
        if(child == 0)      // If we are in the child process
        {
            execvp(args[0],args); // Execute the command
            return 0;
        }
        else
        {
            waitpid(child,&status,0);       // Parent waits for child to terminate
            if(strcmp(args[0],"exit") == 0) // If 'exit' command
                exit(0);                    // Exit program
            else
                if(strcmp(args[0],"cd") == 0) // If 'cd' command
                    chdir(args[1]);           // Change directory
             
            for(int i = 0;i < arg_count;i++)
                args[i] = NULL; // Erase arguments
            arg_count = 0;      // Reset the argument count
        }
    }

    free(input_string);      // Free memory for input_string
    free(input_string_copy); // Free memory for input_string_copy
    return 0;
}
