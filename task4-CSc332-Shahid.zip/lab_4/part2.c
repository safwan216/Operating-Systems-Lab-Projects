#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define STUDENTS 10   // Constant 'STUDENTS' is set to 10

int main()
{
    FILE * grades_file = fopen("grades.txt","r"); // Opens file in 'read mode'
    int columns = 0; // Variable for number of columns in file, will be used to split tasks up later
    char c;                                       // Variable to store the input being read

    while(fscanf(grades_file,"%c",&c)) //Read one character at a time
    {
        if(c == '\n')     // If a new line is reached
        {
            columns += 1; // Increment column count
            break;        // Break out of the loop
        }

        if(c == ' ')      // If blank space is read
            columns += 1; // Increment count
    }

    fseek(grades_file,0,SEEK_SET); // Goes back to the beginning of the file
    int *grade_2D_array[STUDENTS]; // 2D array to store all grades

    for (int i = 0; i < STUDENTS; i++) 
         grade_2D_array[i] = (int *)malloc(columns * sizeof(int)); // Allocates memory for 2D Array
    
    int curr_row  = 0;   // A count to populate rows
    int curr_column = 0; // A count to populate columns
    int curr_grade;      // The grade to put in with the array entry

    while(fscanf(grades_file,"%i",&curr_grade)) // Scans one integer at a time from file and put into curr_grade variable
    {
        grade_2D_array[curr_row][curr_column] = curr_grade; // Sets current row and column in array to the curr_grade
        curr_column += 1; // Increments the column

        if(curr_column == columns)   // If final column
        {
            if(curr_row == STUDENTS) // If final row break out of while loop
                break;
            curr_column = 0; // Resets the current column
            curr_row += 1;   // Goes to next row
        }
    }

    int managers = 2; // Set number of managers

    for(int i = 0;i < managers;i++) // Director
    { 
        if(fork() == 0) // Creates manager for each iteration of loop
        { 
            for(int j = 0;j < (int)(columns/managers);j++) // Manager
            {
                if(fork() == 0) // Creates worker for each column handled by manager
                {
                    float sum = 0;
                    for(int r = 0;r < STUDENTS;r++)
                        sum += grade_2D_array[r][j+(i*managers)]; // Computes the sum of the current column

                    printf("Average for Chapter %i Homework %i: %f\n",i+1,j+1,sum/STUDENTS); // Prints average of current column
                    return 0;
                }
                else
                {
                    wait(NULL); // Waits for each worker to terminate one at a time
                }
            }
            return 0;
        }
        else
        {
            wait(NULL); // Waits for each manager to terminate one at a time
        }
    } 
    fclose(grades_file); // Close file
    for (int i=0; i < STUDENTS; i++) 
        free(grade_2D_array[i]); // Deallocated memory for the array

    return 0;
}
